package com.imakeanapp.imapmovies;


public interface OnMoviesClickCallback {
    void onClick(Movie movie);
}
