# ImapMovies
This app is a product of my Movies App tutorial which can be found here: http://imakeanapp.com/make-a-movies-app-using-tmdb-api-part-1-introduction/

## What will you learn?
* Using Retrofit for networking
* AppBarLayout
* CoordinatorLayout
